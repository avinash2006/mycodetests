document.addEventListener("DOMContentLoaded",

	function(event){

		document.querySelector("button").addEventListener(
			"click", function(){

				$ajaxUtils.sendGetRequest("C:\Users\Pankaja\mycodetests\ajax\data/name.txt",
					function(request){
						var name = request.reponseText;
						console.log(name);
					});

			});
	}
);